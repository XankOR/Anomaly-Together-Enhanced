AnomalyTogetherEnhanced - объединённый аддон для S.T.A.L.K.E.R. Anomaly Together (G.A.M.M.A. 2.8.11F)

Содержит три бывших плагина в одном моде:
  1. Revive + RanksPatch (v22): подъём аптечкой, имена, аватары, цветные метки игроков на карте КПК,
     эмблема над головой, синхронизация рангов, настройки в MCM.
  2. MPTransfer: передача предметов и денег между игроками (ПКМ по предмету в инвентаре).
  3. Custom UI: новое главное меню и экран загрузки.

УСТАНОВКА
  Mod Organizer 2: Install a new mod from archive, затем поставить мод НИЖЕ "AnomalyTogether" в левой панели
  (больший номер приоритета выигрывает; патч должен грузиться после оригинального мода).
  Вручную: содержимое папки gamedata скопировать в gamedata мода AnomalyTogether с заменой.
  Нужен у ВСЕХ игроков (у хоста и у клиентов одинаково).
  Старые три плагина ОТКЛЮЧИТЬ/УДАЛИТЬ, иначе файлы будут дублироваться.

ЧТО ВНУТРИ gamedata
  scripts/   MPCallbacks, MPMain_Downed, MPMain_GamePatches, MPMain_Names, MPMain_PlayerInfo, MPMain_RankSync,
             MPMain_ReviveDialog, MPMain_ReviveMenu, MPMain_Transfer, modxml_map_spots, radmp_multiplayer_mcm
  configs/   ui, ui/textures_descr, text (rus/eng), gameplay
  textures/  ui/ui_radmp (значки, меню аптечки), ui_actor_main_menu.dds, ui_actor_loadgame_screen.dds
  extras/sprite_kit - исходники для художника (в игре не используется, можно удалить).

REVIVE / RANKS / МЕТКИ
  Настройки: MCM -> AnomalyTogether (группа werasik2aa).
  Свои цветные стрелки игроков на карте применяются после ПЕРЕЗАПУСКА игры.
  Перед удалением мода: выключите эту опцию, подождите пару секунд и сохраните игру
  (иначе в сохранении останется метка неизвестного типа).
  Лог: [INFO] own avatar/colour, [INFO] map: ..., [INFO] diag: ..., 'DXML AnomalyTogether minimap: ... hit(s)'.

TRANSFER
  Предмет: ПКМ по предмету -> Передать "Имя" (по пункту на каждого игрока рядом).
  Бумажник: ПКМ -> Передать "Имя" -> окно ввода суммы.
  Настройки в начале MPMain_Transfer_STOGETHER.script: TRANSFER_RANGE, WALLET_SECTIONS, BLOCKED_SECTIONS.
  Лог: строки "[Transfer]". Если бумажник не распознан: "[Transfer] item menu: section=... wallet=false" -
  впишите секцию в WALLET_SECTIONS.
  Новое в объединённой версии: пока игрок ранен (downed) или в критическом состоянии, пункты передачи
  не показываются и передача блокируется.

CUSTOM UI
  Заменяет ui_actor_main_menu.dds и ui_actor_loadgame_screen.dds. Если нужен стандартный экран - удалите эти два файла.

ИЗМЕНЕНИЯ ОБЪЕДИНЁННОЙ ВЕРСИИ
  - Разделка мутантов (MPMain_GamePatches): синхронизация "лута" обёрнута в защиту - сбой синхронизации или
    отсутствующий аддон-модуль больше не ломает саму разделку, причина пишется в лог
    ("[GameManager] mutant loot ... failed: ..."). Обработчик remote_monster_looted проверяет id/объект/окно,
    SetMutantImage передаёт в Frect числа, а не строки.
  - Диалог подъёма (MPMain_ReviveDialog): подпись кнопки аптечки теряла количество (функция в цепочке
    "and" возвращает одно значение) и падала на string.format - исправлено.
  - Удалён неиспользуемый код (M_hit_measuring, мёртвые присваивания в SetMutantImage).
  - Transfer: передача блокируется, пока игрок ранен/в критическом состоянии.
